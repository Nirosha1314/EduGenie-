import os
from functools import lru_cache

MODEL_NAME = "MBZUAI/LaMini-Flan-T5-783M"


@lru_cache(maxsize=1)
def _load_local_model():
    """Load LaMini-Flan-T5 only when it is actually needed."""
    from transformers import AutoTokenizer, AutoModelForSeq2SeqLM

    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
    model = AutoModelForSeq2SeqLM.from_pretrained(MODEL_NAME)
    return tokenizer, model


def _local_explanation(topic: str) -> str:
    tokenizer, model = _load_local_model()

    prompt = (
        "Explain the following educational topic simply for a beginner. "
        "Use short paragraphs and simple examples.\n\n"
        f"Topic: {topic}"
    )
    inputs = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=512)
    output = model.generate(
        **inputs,
        max_new_tokens=220,
        num_beams=4,
        early_stopping=True,
    )
    return tokenizer.decode(output[0], skip_special_tokens=True).strip()


def explain_topic(topic: str) -> str:
    """Explain a concept with the local LaMini model.

    Set USE_LOCAL_EXPLAINER=false to use Gemini instead. If the local
    model is unavailable, Gemini is used as a practical fallback.
    """
    use_local = os.getenv("USE_LOCAL_EXPLAINER", "true").lower() == "true"

    if use_local:
        try:
            return _local_explanation(topic)
        except Exception:
            pass

    from qna import generate_gemini_text

    return generate_gemini_text(
        f"""Explain the educational topic below for a beginner.
Use simple language, short sections, and one small example.

Topic: {topic}"""
    )
