from qna import generate_gemini_text


def summarize_text(text: str) -> str:
    return generate_gemini_text(
        f"""Summarize the educational passage below for quick revision.
Keep the important facts, remove repetition, and use clear bullet points where helpful.
Do not add information that is not supported by the passage.

Passage:
{text}"""
    )
