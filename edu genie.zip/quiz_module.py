import json
import re

from qna import generate_gemini_text


def clean_json_block(text: str) -> str:
    """Remove Markdown code fences and return the JSON portion."""
    cleaned = text.strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"\s*```$", "", cleaned)
    return cleaned.strip()


def _validate_quiz(data):
    if not isinstance(data, list) or len(data) != 3:
        raise ValueError("Quiz must contain exactly 3 questions.")

    for question in data:
        if not isinstance(question, dict):
            raise ValueError("Each quiz question must be an object.")

        required = {"question", "options", "correct_answer"}
        if not required.issubset(question):
            raise ValueError("Each question must contain question, options and correct_answer.")

        options = question["options"]
        if not isinstance(options, list) or len(options) != 4:
            raise ValueError("Each question must contain exactly 4 options.")

        if question["correct_answer"] not in options:
            raise ValueError("correct_answer must match one of the options.")

    return data


def generate_quiz(passage: str):
    prompt = f"""Create exactly 3 multiple-choice questions from the educational passage below.

Return ONLY valid JSON. Do not use Markdown.

JSON format:
[
  {{
    "question": "Question text",
    "options": ["A", "B", "C", "D"],
    "correct_answer": "A"
  }}
]

Passage:
{passage}"""

    raw = generate_gemini_text(prompt)
    data = json.loads(clean_json_block(raw))
    return _validate_quiz(data)
