from qna import generate_gemini_text


def get_learning_recommendations(topic: str) -> str:
    return generate_gemini_text(
        f"""Create a personalized learning path for the topic below.

Organize it from:
1. Beginner fundamentals
2. Intermediate concepts
3. Advanced concepts
4. Practice/projects
5. Revision and next steps

For each stage, give suggested topics, an approximate timeline, and useful
resource types such as documentation, videos, articles, books, or practice sites.
Keep the plan practical and suitable for a learner.

Topic:
{topic}"""
    )
