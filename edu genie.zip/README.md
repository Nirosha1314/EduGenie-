# EduGenie — Google Gemini Powered Learning Assistant

EduGenie is a lightweight AI-powered educational assistant based on the supplied project documentation.

## Features

- Ask academic/general educational questions
- Explain difficult concepts
- Generate 3-question MCQ quizzes
- Summarize educational passages
- Generate beginner-to-advanced learning paths
- FastAPI backend
- HTML/CSS/JavaScript frontend
- Google Gemini API integration
- Optional local LaMini-Flan-T5-783M explanation model

## Project Structure

```text
EduGenie/
├── main.py
├── explanation_module.py
├── qna.py
├── quiz_module.py
├── summary_module.py
├── learning_path.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── EduGenie_Documentation.pdf
├── templates/
│   └── index.html
└── static/
    └── style.css
```

## VS Code Setup

### 1. Open the folder

Open this `EduGenie` folder in VS Code.

### 2. Create a virtual environment

Windows:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Configure Gemini

Copy `.env.example` to `.env`:

```text
GEMINI_API_KEY=your_gemini_api_key_here
```

Never commit `.env` or your real API key to GitHub.

### 5. Run

```bash
uvicorn main:app --reload
```

Open:

```text
http://127.0.0.1:8000
```

API documentation:

```text
http://127.0.0.1:8000/docs
```

## API Endpoints

- `POST /qa`
- `POST /explain`
- `POST /quiz`
- `POST /summarize`
- `POST /learn/recommendations`

## Explanation Model

By default, `USE_LOCAL_EXPLAINER=true`, so EduGenie first attempts to use
`MBZUAI/LaMini-Flan-T5-783M` locally for concept explanations.

If the local model cannot be loaded, the application falls back to Gemini.

For a simpler Gemini-only setup, use:

```env
USE_LOCAL_EXPLAINER=false
```

## Testing the Application

1. Open the browser interface.
2. Select **Ask a Question** and enter a question.
3. Select **Explain a Topic** and enter a concept.
4. Select **Generate Quiz** and paste educational text.
5. Select **Summarize** and paste a passage.
6. Select **Learning Path** and enter a topic.

## GitHub Safety

Do not upload:

- `.env`
- Gemini API keys
- private credentials
- local model cache folders

The included `.gitignore` already excludes `.env`, virtual environments, caches, and common local files.

## Documentation

`EduGenie_Documentation.pdf` contains the project details together with the complete code for the eight requested files.
