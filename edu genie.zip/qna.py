from dotenv import load_dotenv
load_dotenv()

import os
from functools import lru_cache

DEFAULT_MODEL = "gemini-2.5-flash"


@lru_cache(maxsize=1)
def _client():
    from google import genai

    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise RuntimeError(
            "GEMINI_API_KEY is not configured. Create a .env file and add your Gemini API key."
        )
    return genai.Client(api_key=api_key)


def generate_gemini_text(prompt: str) -> str:
    """Send a prompt to Google Gemini and return plain text."""
    response = _client().models.generate_content(
        model=os.getenv("GEMINI_MODEL", DEFAULT_MODEL),
        contents=prompt,
    )
    text = getattr(response, "text", None)
    if not text:
        raise RuntimeError("Gemini returned an empty response.")
    return text.strip()


def answer_question(question: str) -> str:
    return generate_gemini_text(
        f"""You are EduGenie, an educational assistant.
Answer the student's question accurately and concisely.
Explain difficult terms when useful. Do not invent sources.

Student question:
{question}"""
    )
